export var Global = {
    url: 'https://quiet-crag-80659.herokuapp.com/scm-unibague/'
  };