import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-show',
  templateUrl: './info-show.component.html',
  styleUrls: ['./info-show.component.css']
})
export class InfoShowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
