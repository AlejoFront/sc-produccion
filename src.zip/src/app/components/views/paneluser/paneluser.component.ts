import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paneluser',
  templateUrl: './paneluser.component.html',
  styleUrls: ['./paneluser.component.css']
})
export class PaneluserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
