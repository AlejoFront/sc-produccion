export class StateBranchOffice {
    constructor(
        public code: number,
        public description: String 
    ){}
}