export class Timeremaining {
    constructor(
        public code: number,
        public data: String
    ){}
}