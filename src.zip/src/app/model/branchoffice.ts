export class Branchoffice {
    constructor(
        public code: number,
        public address: String,
        public enterpriseNit: String,
        public stateBranchOffice: any 
    ){}
}