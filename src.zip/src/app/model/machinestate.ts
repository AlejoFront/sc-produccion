export class Machinestate {
    constructor(
        public code: number,
        public description: String 
    ){}
}