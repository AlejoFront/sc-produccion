export class Requeststate {
    constructor(
        public code: number,
        public description: String 
    ){}
}