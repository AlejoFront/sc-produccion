export class Infomachine {
    constructor(
        public code: number,
        public name: String,
        public productionCapacity: number,
        public reference: String
    ){}
}