export interface Productions {
    code: number;
    createDate: String;
    expirationDate: String;
    startOrderDate: String;
    time: String;
}