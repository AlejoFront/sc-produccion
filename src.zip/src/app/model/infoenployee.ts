export class Infoemployee {
    constructor(
        public code: number,
        public dni: String,
        public name: String,
        public workShift: any
    ){}
}